from django.apps import AppConfig

class EnquiriesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'enquiries'
    verbose_name = 'Enquiries & Lead Management'
